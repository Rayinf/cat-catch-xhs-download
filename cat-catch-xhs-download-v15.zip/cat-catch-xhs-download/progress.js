function append(text){const el=document.getElementById('log');el.textContent+=text+'\n';el.scrollTop=el.scrollHeight;}
const params=new URLSearchParams(location.search);
const keyword=params.get('keyword')||'';
const count=parseInt(params.get('count'),10)||20;

document.getElementById('title').textContent=`下载关键词：${keyword} (目标 ${count})`;
append('初始化...');

chrome.runtime.sendMessage({type:'xhs-download',payload:{keyword,count}},resp=>{
  if(resp?.ok){append(`✅ 任务提交，共 ${resp.total} 条`);}else if(resp){append('❌ '+resp.error);} });

chrome.runtime.onMessage.addListener((msg)=>{
  if(msg.type==='progress'){append(msg.text);}  }); 