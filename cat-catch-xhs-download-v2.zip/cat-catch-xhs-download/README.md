# 猫抓·小红书批量下载扩展

> 基于 [xifangczy/cat-catch](https://github.com/xifangczy/cat-catch) 的资源嗅探思路，实现按关键词批量下载小红书视频（仅供技术学习，严禁非法用途）。

## 安装

1. 克隆本仓库，或仅复制 `cat-catch-xhs-download` 目录。
2. 打开浏览器扩展管理页，开启「开发者模式」。
3. 选择「加载已解压的扩展」，指向本目录即可。

## 使用

1. 点击浏览器工具栏图标，打开 popup。
2. 填写关键词（如：旅行攻略）、数量（默认 20）。
3. 点击「开始下载」。需要已登录小红书，且浏览器允许跨域访问。

下载文件会按 `关键词/笔记ID.mp4` 保存到默认下载目录
（Chrome 支持在设置中允许扩展创建子文件夹）。

## 技术要点

- Manifest V3 + service worker 监听消息。
- 直接调用小红书 **非公开** Web API：
  - 搜索：`/api/sns/web/v1/search/notes`
  - 详情：`/api/sns/web/v1/feed?note_id=...`
- 抽取 `note.video.url` 字段，调用 `chrome.downloads.download` 下载。

> 以上 API 可能随时失效，请自行抓包维护。 