/*
 * 背景脚本（service_worker）
 * 参考猫抓的资源捕获逻辑，简化为针对小红书视频批量下载
 * 仅做演示用途，正式使用请自行维护 API 与解析逻辑
 */

const XHS_HOST = 'https://www.xiaohongshu.com';

/**
 * 确保存在搜索结果标签页，并返回其 tabId
 */
async function ensureSearchTab(keyword) {
  const urlSearch = `${XHS_HOST}/search_result?keyword=${encodeURIComponent(keyword)}`;
  // 尝试查找已打开的标签
  const tabs = await chrome.tabs.query({ url: '*://*.xiaohongshu.com/*search_result*' });
  if (tabs.length) {
    const tab = tabs[0];
    // 如果关键词不同可重新导航
    chrome.tabs.update(tab.id, { url: urlSearch, active: false });
    await waitTabComplete(tab.id);
    return tab.id;
  }
  // 新建背景 tab
  const tab = await chrome.tabs.create({ url: urlSearch, active: false });
  await waitTabComplete(tab.id);
  return tab.id;
}

function waitTabComplete(tabId) {
  return new Promise(resolve => {
    function listener(id, changeInfo) {
      if (id === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function downloadByKeyword(keyword, maxCount = 20) {
  const tabId = await ensureSearchTab(keyword);
  // 收集笔记 ID
  const resp = await chrome.tabs.sendMessage(tabId, { type: 'collect-note-ids', targetCount: maxCount });
  const noteIds = resp?.ids ?? [];
  const collected = [];
  for (const nid of noteIds) {
    const { url } = await chrome.tabs.sendMessage(tabId, { type: 'fetch-video-url', noteId: nid });
    if (url) collected.push({ noteId: nid, videoUrl: url });
  }
  for (const { noteId, videoUrl } of collected) {
    const filename = `${keyword}/${noteId}.mp4`;
    chrome.downloads.download({ url: videoUrl, filename, saveAs: false });
  }
  return collected.length;
}

// 监听来自 popup 的消息
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'xhs-download') {
    const { keyword, count } = msg.payload;
    downloadByKeyword(keyword, count)
      .then(total => sendResponse({ ok: true, total }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    // 返回 true 表示异步响应
    return true;
  }
}); 