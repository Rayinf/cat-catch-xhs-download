/*
 * 背景脚本（service_worker）
 * 参考猫抓的资源捕获逻辑，简化为针对小红书视频批量下载
 * 仅做演示用途，正式使用请自行维护 API 与解析逻辑
 */

const XHS_HOST = 'https://www.xiaohongshu.com';

/**
 * 根据关键词搜索笔记列表
 * ⚠️ 小红书接口会变动，需要自行抓包更新
 * @param {string} keyword
 * @param {number} page
 * @param {number} pageSize
 */
async function searchNotes(keyword, page = 1, pageSize = 20) {
  const url = `${XHS_HOST}/api/sns/web/v1/search/notes?keyword=${encodeURIComponent(keyword)}&page=${page}&page_size=${pageSize}`;
  const resp = await fetch(url, {
    credentials: 'include',
    headers: {
      'x-sns-plat': 'web'
    }
  });
  if (!resp.ok) throw new Error(`搜索失败(${resp.status})`);
  const data = await resp.json();
  return data?.data?.items ?? [];
}

/**
 * 提取单条笔记对应的视频直链
 * @param {string} noteId
 */
async function extractVideoUrl(noteId) {
  const url = `${XHS_HOST}/api/sns/web/v1/feed?note_id=${noteId}`;
  const resp = await fetch(url, { credentials: 'include' });
  if (!resp.ok) return null;
  const data = await resp.json();
  const video = data?.data?.note?.video ?? null;
  return video?.url ?? null;
}

/**
 * 批量下载指定关键词的视频
 * @param {string} keyword
 * @param {number} maxCount
 */
async function downloadByKeyword(keyword, maxCount = 20) {
  let page = 1;
  const collected = [];
  while (collected.length < maxCount) {
    const notes = await searchNotes(keyword, page, 20);
    if (!notes.length) break;
    for (const n of notes) {
      if (collected.length >= maxCount) break;
      const noteId = n.id || n.note_id;
      const videoUrl = await extractVideoUrl(noteId);
      if (videoUrl) collected.push({ noteId, videoUrl });
    }
    page += 1;
  }
  // 触发下载
  for (const { noteId, videoUrl } of collected) {
    const filename = `${keyword}/${noteId}.mp4`;
    chrome.downloads.download({ url: videoUrl, filename, saveAs: false });
  }
  return collected.length;
}

// 监听来自 popup 的消息
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'xhs-download') {
    const { keyword, count } = msg.payload;
    downloadByKeyword(keyword, count)
      .then(total => sendResponse({ ok: true, total }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    // 返回 true 表示异步响应
    return true;
  }
}); 