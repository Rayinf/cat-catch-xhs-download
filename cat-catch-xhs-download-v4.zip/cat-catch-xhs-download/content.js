/*
 * content.js - 注入到小红书页面，用于在站内环境收集笔记 ID 并获取视频直链。
 */

/**
 * 获取当前页面已渲染的笔记 ID 列表
 */
function collectNoteIds() {
  const anchors = Array.from(document.querySelectorAll('a[href*="/explore/"]'));
  const ids = new Set();
  anchors.forEach(a => {
    const m = a.href.match(/\/explore\/([0-9a-fA-F]+)/);
    if (m) ids.add(m[1]);
  });
  return Array.from(ids);
}

/**
 * 尝试滚动加载更多内容，直到收集到足够数量或触底
 */
async function gatherEnoughIds(targetCount) {
  let ids = collectNoteIds();
  let prevHeight = 0;
  let retries = 0;
  while (ids.length < targetCount && retries < 10) {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    await new Promise(r => setTimeout(r, 1200));
    ids = collectNoteIds();
    if (document.body.scrollHeight === prevHeight) retries += 1;
    else prevHeight = document.body.scrollHeight;
  }
  return ids.slice(0, targetCount);
}

/**
 * 从笔记详情 HTML 提取视频直链
 */
async function fetchVideoUrl(noteId) {
  try {
    const html = await fetch(`/explore/${noteId}`).then(r => r.text());
    // 使用安全字符串正则避免解析错误
    const match = html.match(/https:\\/\\/sns-video[^"\\]+/);
    if (match) {
      return match[0].replace(/\\/g, '');
    }
  } catch (e) {
    console.error('fetchVideoUrl error', noteId, e);
  }
  return null;
}

// 监听 background 发送的请求
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'collect-note-ids') {
    gatherEnoughIds(msg.targetCount).then(ids => sendResponse({ ids }));
    return true;
  }
  if (msg.type === 'fetch-video-url') {
    const { noteId } = msg;
    fetchVideoUrl(noteId).then(url => sendResponse({ url }));
    return true;
  }
}); 