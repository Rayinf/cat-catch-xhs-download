/*
 * content.js - 注入到小红书页面，用于在站内环境收集笔记 ID 并获取视频直链。
 */

/**
 * 获取当前页面已渲染的笔记 ID 列表
 */
function collectNoteIds() {
  const anchors = Array.from(document.querySelectorAll('a[href*="/explore/"]'));
  const ids = new Set();
  anchors.forEach(a => {
    const m = a.href.match(/\/explore\/([0-9a-fA-F]+)/);
    if (m) ids.add(m[1]);
  });
  return Array.from(ids);
}

/**
 * 尝试滚动加载更多内容，直到收集到足够数量或触底
 */
async function gatherEnoughIds(targetCount) {
  let ids = collectNoteIds();
  let prevHeight = 0;
  let retries = 0;
  while (ids.length < targetCount && retries < 10) {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    await new Promise(r => setTimeout(r, 1200));
    ids = collectNoteIds();
    if (document.body.scrollHeight === prevHeight) retries += 1;
    else prevHeight = document.body.scrollHeight;
  }
  return ids.slice(0, targetCount);
}

/**
 * 从笔记详情 HTML 提取视频直链
 */
async function fetchVideoUrl(noteId) {
  try {
    const html = await fetch(`/explore/${noteId}`).then(r => r.text());
    // 搜索 mp4 直链
    const match = html.match(/https?:\/\/sns-video[^"']+\.mp4/);
    if (match) {
      return match[0];
    }
  } catch (e) {
    console.error('fetchVideoUrl error', noteId, e);
  }
  return null;
}

/** 切换到“视频”标签 */
function switchToVideoTab() {
  const tabs = Array.from(document.querySelectorAll('div, span, a'));
  const videoTab = tabs.find(el => el.innerText?.trim() === '视频');
  if (videoTab) {
    videoTab.click();
    return true;
  }
  return false;
}

/** 在详情页提取视频直链 */
function extractVideoFromDetail() {
  // 1. 先尝试 video 标签
  const v = document.querySelector('video');
  if (v?.src) return v.src;
  // 2. 搜索页面源码中的 sns-video mp4
  const html = document.documentElement.innerHTML;
  const m = html.match(/https?:\/\/sns-video[^\"]+\.mp4/);
  return m ? m[0] : null;
}

/**
 * 收集视频直链
 */
async function collectVideoItems(maxCount) {
  // 确保在视频标签
  switchToVideoTab();
  await new Promise(r => setTimeout(r, 1200));

  const ids = await gatherEnoughIds(maxCount);
  const items = [];
  for (const id of ids) {
    const url = await fetchVideoUrl(id);
    if (url) items.push({ noteId: id, url });
    if (items.length >= maxCount) break;
  }
  return items;
}

/** 等待条件成立工具 */
function waitFor(fn, timeout = 8000, interval = 200) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const timer = setInterval(() => {
      try {
        const res = fn();
        if (res) {
          clearInterval(timer);
          resolve(res);
        } else if (Date.now() - start > timeout) {
          clearInterval(timer);
          reject(new Error('waitFor timeout'));
        }
      } catch (e) {
        clearInterval(timer);
        reject(e);
      }
    }, interval);
  });
}

async function fetchVideoUrlFromAnchor(anchor) {
  const url = anchor.getAttribute('href');
  if (!url) return null;
  try {
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) return null;
    const html = await resp.text();
    const m = html.match(/https?:\/\/sns-video[^"']+\.mp4/);
    return m ? m[0] : null;
  } catch (e) { console.warn('fetch detail failed', e); return null; }
}

function getCardAnchors() {
  return Array.from(document.querySelectorAll('section.note-item a.cover[href]'));
}

async function collectVideoItemsByFetch(maxCount, keyword) {
  chrome.runtime.sendMessage({type:'progress',text:`开始抓取关键词「${keyword}」...`});
  switchToVideoTab();
  await new Promise(r => setTimeout(r, 1000));

  let anchors = getCardAnchors();
  let idx = 0;
  const items = [];
  const seen = new Set();

  while (items.length < maxCount && idx < anchors.length) {
    const a = anchors[idx];
    const href = a.getAttribute('href');
    const m = href.match(/([0-9a-fA-F]{10,})/);
    const noteId = m ? m[1] : `idx${idx}`;
    if (seen.has(noteId)) { idx +=1; continue; }
    seen.add(noteId);
    try {
      const videoUrl = await fetchVideoUrlFromAnchor(a);
      if (videoUrl) {
        items.push({ noteId, url: videoUrl });
        await downloadBlob(videoUrl, `${keyword}/${noteId}.mp4`);
      }
    } catch {
      // fetch failed, remove from seen to allow retry later
      seen.delete(noteId);
    }
    idx += 1;
    if (items.length < maxCount && idx >= anchors.length) {
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
      await new Promise(r => setTimeout(r, 1200));
      anchors = getCardAnchors();
    }
  }
  chrome.runtime.sendMessage({type:'progress',text:`🎉 下载完成 共 ${items.length} 个`});
  return items;
}

async function downloadBlob(url, filename) {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(resp.status);
  const blob = await resp.blob();
  const objUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = objUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(objUrl);
  chrome.runtime.sendMessage({type:'progress',text:`✅ 保存 ${filename}`});
}

// 监听 background 发送的请求
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'collect-video-items') {
    collectVideoItemsByFetch(msg.maxCount || 20, msg.keyword || 'xhs').then(items => sendResponse({ items }));
    return true;
  }
  if (msg.type === 'switch-to-video-tab') {
    const ok = switchToVideoTab();
    sendResponse({ ok });
    return true;
  }
  if (msg.type === 'collect-note-ids') {
    gatherEnoughIds(msg.targetCount).then(ids => sendResponse({ ids }));
    return true;
  }
  if (msg.type === 'get-video-url') {
    const url = extractVideoFromDetail();
    sendResponse({ url });
    return true;
  }
  if (msg.type === 'fetch-video-url') {
    const { noteId } = msg;
    fetchVideoUrl(noteId).then(url => sendResponse({ url }));
    return true;
  }
}); 