/*
 * 背景脚本（service_worker）
 * 参考猫抓的资源捕获逻辑，简化为针对小红书视频批量下载
 * 仅做演示用途，正式使用请自行维护 API 与解析逻辑
 */

const XHS_HOST = 'https://www.xiaohongshu.com';

/**
 * 确保存在搜索结果标签页，并返回其 tabId
 */
async function ensureSearchTab(keyword) {
  const urlSearch = `${XHS_HOST}/search_result?keyword=${encodeURIComponent(keyword)}`;
  // 尝试查找已打开的标签
  const tabs = await chrome.tabs.query({ url: '*://*.xiaohongshu.com/*search_result*' });
  if (tabs.length) {
    const tab = tabs[0];
    // 如果关键词不同可重新导航
    chrome.tabs.update(tab.id, { url: urlSearch, active: false });
    await waitTabComplete(tab.id);
    return tab.id;
  }
  // 新建背景 tab
  const tab = await chrome.tabs.create({ url: urlSearch, active: false });
  await waitTabComplete(tab.id);
  return tab.id;
}

function waitTabComplete(tabId) {
  return new Promise(resolve => {
    function listener(id, changeInfo) {
      if (id === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function sendMessagePromise(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, resp => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(resp);
      }
    });
  });
}

async function downloadByKeyword(keyword, maxCount = 20) {
  const tabId = await ensureSearchTab(keyword);
  // 注入脚本确保存在
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  // 直接让 content script 收集视频列表
  const { items } = await sendMessagePromise(tabId, { type: 'collect-video-items', maxCount, keyword });
  return items.length;
}

// 监听来自 popup 的消息
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'xhs-download') {
    const { keyword, count } = msg.payload;
    downloadByKeyword(keyword, count)
      .then(total => sendResponse({ ok: true, total }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    // 返回 true 表示异步响应
    return true;
  }
}); 