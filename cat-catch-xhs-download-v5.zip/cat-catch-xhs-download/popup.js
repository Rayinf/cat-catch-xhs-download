function appendLog(text) {
  const el = document.getElementById('log');
  el.textContent += `${text}\n`;
  el.scrollTop = el.scrollHeight;
}

document.getElementById('btn-download').addEventListener('click', () => {
  const keyword = document.getElementById('keyword').value.trim();
  const count = parseInt(document.getElementById('count').value, 10) || 20;
  if (!keyword) {
    appendLog('⚠️ 请输入关键词');
    return;
  }
  appendLog(`开始下载：${keyword} (数量 ${count})`);
  chrome.runtime.sendMessage(
    {
      type: 'xhs-download',
      payload: { keyword, count }
    },
    resp => {
      if (resp?.ok) {
        appendLog(`✅ 完成下载 ${resp.total} 个文件`);
      } else {
        appendLog(`❌ 下载失败：${resp?.error ?? '未知错误'}`);
      }
    }
  );
}); 